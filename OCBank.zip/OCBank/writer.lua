writer = require("component").os_cardwriter

writer.write("defaultUser", "Name", false)